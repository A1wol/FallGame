import coinImage from "../Assets/coin.png";
import norbertNameImage from "../Assets/norbertName.png";
import platformImage from "../Assets/platform.png";
import grassImage from "../Assets/grass.png";
import playerImageRight from "../Assets/playerRight1.png";
import playerImageRight2 from "../Assets/playerRight2.png";
import playerImageLeft from "../Assets/playerLeft1.png";
import playerImageUp from "../Assets/playerUp.png";
import playerImageHit from "../Assets/playerHit.png";
import mobImage from "../Assets/mobImage.png";
import norbertImage from "../Assets/norbertImage.png";

const canvas = document.querySelector("#myCanvas");
const c = canvas.getContext("2d");
let coinImg = new Image();
coinImg.src = coinImage;

let norbertName = new Image();
norbertName.src = norbertNameImage;

let platformImg = new Image();
platformImg.src = platformImage;

let grassImg = new Image();
grassImg.src = grassImage;

let playerImgRight = new Image();
playerImgRight.src = playerImageRight;
let playerImgRight2 = new Image();
playerImgRight2.src = playerImageRight2;
let playerImgLeft = new Image();
playerImgLeft.src = playerImageLeft;
let playerImgUp = new Image();
playerImgUp.src = playerImageUp;
let playerHit = new Image();
playerHit.src = playerImageHit;
let mobImg = new Image();
mobImg.src = mobImage;
let norbertImg = new Image();
norbertImg.src = norbertImage;

const keys = {
  up: {
    pressed: false,
  },
  right: {
    pressed: false,
  },
  left: {
    pressed: false,
  },
  f: {
    pressed: true,
  },
};

function getRandomInt(max) {
  return Math.floor(Math.random() * max);
}
function getImageSrc() {
  if (getRandomInt(2) === 0) {
    return playerImgRight;
  } else {
    return playerImgRight2;
  }
}
class Player {
  constructor() {
    this.position = {
      x: 100,
      y: 100,
    }; // startowa pozycja gracza
    this.velocity = {
      x: 0,
      y: 1,
    }; // predkosc

    // rozmiar gracza
    this.width = 70;
    this.height = 100;
  }
  draw() {
    // umieszczenie gracza w oknie gry
    if (keys.f.pressed) {
      c.drawImage(playerHit, this.position.x, this.position.y, 100, 130);
    } else {
      if (!keys.left.pressed && !keys.up.pressed) {
        c.drawImage(getImageSrc(), this.position.x, this.position.y, 100, 130);
      } else if (keys.left.pressed && !keys.up.pressed) {
        c.drawImage(playerImgLeft, this.position.x, this.position.y, 100, 130);
      } else if (keys.up.pressed) {
        c.drawImage(playerImgUp, this.position.x, this.position.y, 100, 130);
      }
    }
  }
  update() {
    // zmiana pozycji gracza + symulacja grawitacji
    this.draw();
    this.position.y += this.velocity.y;
    this.position.x += this.velocity.x;
    if (this.position.y + this.height + this.velocity.y + 20 <= canvas.height) {
      this.velocity.y += 0.3;
    } else {
      this.velocity.y = 0;
    }
  }
}
let amountOfUsersCoins = 0;
class Coin {
  constructor({ x, y, image, width, height, visibility }) {
    this.position = {
      x,
      y,
    };
    this.width = width;
    this.height = height;
    this.image = image;
    this.visibility = visibility;
  }
  draw() {
    c.drawImage(
      this.image,
      this.position.x,
      this.position.y,
      this.width,
      this.height
    );
  }
}
class Mob {
  constructor({ x, y, image, width, height, visibility }) {
    this.position = {
      x,
      y,
    };
    this.width = width;
    this.height = height;
    this.image = image;
    this.visibility = visibility;
  }
  draw() {
    c.drawImage(
      this.image,
      this.position.x,
      this.position.y,
      this.width,
      this.height
    );
  }
}
const coins = [
  new Coin({
    x: 3020,
    y: 220,
    width: 50,
    height: 50,
    image: coinImg,
    visibility: true,
  }),
  new Coin({
    x: 2350,
    y: 320,
    width: 50,
    height: 50,
    image: coinImg,
    visibility: true,
  }),
  new Coin({
    x: 4300,
    y: 20,
    width: 50,
    height: 50,
    image: coinImg,
    visibility: true,
  }),
  new Coin({
    x: 4700,
    y: 270,
    width: 50,
    height: 50,
    image: coinImg,
    visibility: true,
  }),
  new Coin({
    x: 3250,
    y: 370,
    width: 50,
    height: 50,
    image: coinImg,
    visibility: true,
  }),
  new Coin({
    x: 2300,
    y: 90,
    width: 50,
    height: 50,
    image: coinImg,
    visibility: true,
  }),
  new Coin({
    x: 4500,
    y: 220,
    width: 50,
    height: 50,
    image: coinImg,
    visibility: true,
  }),
  new Coin({
    x: 3250,
    y: 320,
    width: 50,
    height: 50,
    image: coinImg,
    visibility: true,
  }),
  new Coin({
    x: 2300,
    y: 20,
    width: 50,
    height: 50,
    image: coinImg,
    visibility: true,
  }),
];
const mobs = [
  new Mob({
    x: 1000,
    y: 220,
    width: 100,
    height: 100,
    image: mobImg,
    visibility: true,
  }),
  new Mob({
    x: 250,
    y: 320,
    width: 100,
    height: 100,
    image: mobImg,
    visibility: true,
  }),
  new Mob({
    x: 1500,
    y: 20,
    width: 100,
    height: 100,
    image: mobImg,
    visibility: true,
  }),
  new Mob({
    x: 3000,
    y: 515,
    width: 100,
    height: 100,
    image: mobImg,
    visibility: true,
  }),
  new Mob({
    x: 3000,
    y: 150,
    width: 100,
    height: 100,
    image: mobImg,
    visibility: true,
  }),
  new Mob({
    x: 1250,
    y: 95,
    width: 100,
    height: 100,
    image: mobImg,
    visibility: true,
  }),
  new Mob({
    x: 1500,
    y: 515,
    width: 100,
    height: 100,
    image: mobImg,
    visibility: true,
  }),
  new Mob({
    x: 4700,
    y: 515,
    width: 100,
    height: 100,
    image: mobImg,
    visibility: true,
  }),
  new Mob({
    x: 4200,
    y: 515,
    width: 100,
    height: 100,
    image: mobImg,
    visibility: true,
  }),
  new Mob({
    x: 4300,
    y: 515,
    width: 100,
    height: 100,
    image: mobImg,
    visibility: true,
  }),
  // główny boss
  new Mob({
    x: 5000,
    y: 415,
    width: 200,
    height: 200,
    image: norbertImg,
    visibility: true,
  }),
];

class Platform {
  constructor({ x, y, image, width, height }) {
    this.position = {
      x,
      y,
    };
    this.width = width;
    this.height = height;
    this.image = image;
  }
  draw() {
    c.drawImage(
      this.image,
      this.position.x,
      this.position.y,
      this.width,
      this.height
    );
  }
}
const player = new Player();

let amountOfNorbertsHealth = 500;
const platforms = [
  new Platform({
    x: 100,
    y: 400,
    width: 350,
    height: 35,
    image: platformImg,
  }),
  new Platform({
    x: 650,
    y: 200,
    width: 350,
    height: 35,
    image: platformImg,
  }),
  new Platform({
    x: 950,
    y: 300,
    width: 350,
    height: 35,
    image: platformImg,
  }),
  new Platform({
    x: 0,
    y: 585,
    width: 2500,
    height: 50,
    image: grassImg,
  }),
  new Platform({
    x: 2500,
    y: 585,
    width: 2500,
    height: 50,
    image: grassImg,
  }),
  new Platform({
    x: 5000,
    y: 585,
    width: 2500,
    height: 50,
    image: grassImg,
  }),
  new Platform({
    x: 1250,
    y: 100,
    width: 350,
    height: 35,
    image: platformImg,
  }),
  new Platform({
    x: 1500,
    y: 450,
    width: 350,
    height: 35,
    image: platformImg,
  }),
  new Platform({
    x: 1750,
    y: 100,
    width: 350,
    height: 35,
    image: platformImg,
  }),
  new Platform({
    x: 2100,
    y: 450,
    width: 350,
    height: 35,
    image: platformImg,
  }),
  new Platform({
    x: 2450,
    y: 370,
    width: 350,
    height: 35,
    image: platformImg,
  }),
  new Platform({
    x: 2700,
    y: 250,
    width: 350,
    height: 35,
    image: platformImg,
  }),
  new Platform({
    x: 5000,
    y: 350,
    width: 250,
    height: 50,
    image: norbertName,
  }),
];

let currentLvl = 1;

// const platf
player.update();
function animate() {
  // animacja gracza
  requestAnimationFrame(animate);
  c.clearRect(0, 0, canvas.width, canvas.height);
  player.update();
  platforms.forEach((platform) => {
    platform.draw();
  });

  document.querySelector(
    "#collectedCoins"
  ).innerHTML = `${amountOfUsersCoins} / ${coins.length}`;
  coins.forEach((coin) => {
    if (coin.visibility) {
      coin.draw();
    }
    if (
      coin.position.x - player.position.x < 20 &&
      coin.visibility === true &&
      coin.position.y - player.position.y < 50 &&
      player.position.y - coin.position.y < 50
    ) {
      coin.visibility = false;
      amountOfUsersCoins++;
    }
  });
  mobs.forEach((mob) => {
    if (mob.visibility) {
      mob.draw();
    }
    let numberOfKills =
      mobs.length - mobs.filter((mob) => mob.visibility === true).length;
    document.querySelector(
      "#killedMonsters"
    ).innerHTML = `${numberOfKills} / ${mobs.length}`;
    if (
      keys.f.pressed &&
      mob.position.x - player.position.x < 100 &&
      mob.position.y - player.position.y < 50 &&
      mob.image !== norbertImg
    ) {
      mob.visibility = false;
      if (numberOfKills === mobs.length - 1) {
        document.querySelector("#level1Info").style.display = "none";
        document.querySelector("#level2Info").style.display = "flex";

        // przejscie do nastepnego poziomu
        document.getElementById("myCanvas").style.backgroundColor = "black";
        document.getElementById("myCanvas").style.backgroundImage =
          "url(' data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAfAAAAEQCAYAAABP6CZkAAAAAXNSR0IArs4c6QAAD2RJREFUeJzt3WuSm7gCBlD5VhYwm5n9LyCbyQ58f0zjYAwGgdDznKpUMtPtR7eRPvR+/P7zfAZG8gghhH//eYTff14ffc5r4PX6wKdC5ZIGPQT4kObpWeLzj05vgc8IhDcxfpV+AxRRunKIff3HrGIT5vSudPmkEQKcFswrtFeYC3JaNL8ZnSyGtOAQXei0ylg6zdnoIi89pEWj/lf6DcBJzxDWWzNQoy/j2y5iThHgtEzFR2u2rtnp/+tS4jBj4HRja2wRGuGGlCgCnOYtgvtjwpsQ527Lm8cv19wjCGoS0YVO656LP8uvGSfnVoux7dc1t3HduRhJRguc3j2DcUUuOnAT+Fz5tx4gbiXAgeHsBfI8dC/sjvYMi02IICXrwBnBRxNorVVkEtwYDgRy6fMC4BABzoheqTwF9LcNNoR4PyIC2eYqVE+AM7JlMq+VBSHeiROt6elDV0dSJWPgjGw+we3bBhtfJyNtjXEK/fQSDHPEhLEJkFRNCxyOrc19LIPiy/rz6TlDCII8lQP7iL+sDI2sPRaaJsDhWFfp4+TMZF3wKyI2Pll+/5H66sjQCDTvV8jXRaQQUatDIbxyjOmRa1o3bNgcZnhbLz35EuZH65AjQyNQm+h6IkvFUsE6yOJvgG6cmZ380f0+kjOt50TrsCGFbIU3tp7ovla58eZBZcJRw46HnwzftxD/eQ7ljW9uLVi1lts631Xl3BRw0m55q7WiOOtC+BrHJqow9FZ2jhjvJ65UBcMMe6p/gx2ILo81VFqR+4QzntMXaQ3Xd838dthVwc1F8TdQqVvG1k9+3j6jPiW5wATxPWzkwq6She8nTJT+/ARyfYqUA+FbL58M8GanBS7YP1U7S5m+uRqAQ24eSilxY5Cs/hOslOCqA4oqOcdC8AIAAAAAAAAAAAAAAAAAAAAAwMCSbEO0t5NSit2OcrwGALTiUuotQnUrYV+vcSZkc7wGALTmdNrNgvXoRsaPEI4H7MHgvvQaANCq6KQ7Gaxvr7cXsCduDqJfAwBadjjlLgb3x2tuBezF8D70GgDQuv8d+aZFqF49+2/z8YnCO8XjAaBquwGeMFS3nncp2euUPGcYAO70NcDvCu+157shbKU3AN36tfWFG8N77TVufy0A6MnqLK8c4f3z2ncHtslsAHTpI9kyhXdOQhyA7rylWofhPRHiAHRlbQy8t/AO4b+fSXpDR85OfHUjTy9eV3LHre+JVjh0IMdukNCC5TKyXsM7hL5/NhhCgk2lnovngWYd2okNoLTUOzUKcVq3uQ4coBY3DPHtzovZC3jd8JQmwIGiIlrCyZvMB1576xse02MFOaUIcCC7SnZhvPKa02MFOcUIcCCrzla8vAW5ECeVIz1TywDPsb1pKUoWFNZZeM89gxAngYhlko9HJV1ZuVgDCgX91DfqGFgRe4P76+g3dsKObFDIIMu21DGccqZ36vH7z3OIUjXTzR3y1Qqxh98Bbei463xNN3UMeZwtHyNOYmviDjnD0hqzZ8lisPAOoZE6hjpcKR8jBvhXpTdvuLjPcwyzZ8lplPCGw67e3ArwHweD89ZWa6GWitmz3GaQcW+IlqK+H3Yv9HnFEnFAwuvrqSumwt2M9oYmuQG7zt8oTxxw6SIZNcBfgXWykkkaeJVUdGob7jDqdeWmmE2protRAzyE99Z2DccSVlHSVTiQjBDnm8sXxsgBPkmxH/JplRXuqt4MdECI8ybltWASWwJnJ4BV0nUepfQsfWiQZWUsJanzBfh1pwpna+Fdwyx96rZxc9fz+QpRrPQgdU+MAC+g4fDee7/Wlg9m5ywFF8BfWuFMktX7AjyzjsN7ztryzuy0HLa+2MQ1Dq0S4BkNEt7zxwjxDrR23bbgSFeqcsMeAZ5f9ZVgwu1cdRs2TninFXPW8/x7hXlXks0LsYwsk4aWkeztRhetoZ+ddT7ANOb7ThyZT3Lbzo+UMbsRS3JHJsATmXZ1W+zuttRSKUwV5C39zHC3GjaNoqCUvSkCPI1nWLljVuCARIR4fy4nuQC/h64vIDWVSSdSdaWbxHav10zs0S1/ByblNMVmLBWxsqM7p8vX4/efp4J5v6m0+V3/51X7qIjy2rqZ/PY5mIlenYdy066Eq3x0oWei4ntniCGzlaNzzXKGzFbK4CVa4Ploha97hKAlfqeDLei3z2Fni1TK0gK/IOZmNeXv+Y6eLAGel7HEdUL8JpGVxvIDcK3WaTfAv4XUqOXsRNd1sqG+u4ahTGLLT4h/smPbvY5eb67LRnw79W8nLIYrZxfGnJMcznTnHBIt8LzmV4Df+zut8EgRXYGutT6tlpmf62LrM98sYD2WvYTheap+unsCqACnJsb2Zg4GtPI7tq0CszvfYfE93d1A3xCe0b+jnZupy3ShQ90ENN+8unkX/33kMcv/183pgTe1fD+G+kqv3hDgULeUtambgX6lOrfgY+Op1gL97m7rmlZoCHCo1A1LWM48YenQz50epX/e0pY/f1vp/dddn+O8FV78WhHgMIAzNwMXQj+pXC3Am3/e3JV98c+thExd2sWDeyLAgVWtdZ1eddfPW+pGaLTPb6aagL2bAKcWw9Y29G3gIOVm9kKnGio6gOMEODWQ3ACRBDgAzSu9JrsEAU4Nxit5QDKjnlkvwKnGiHfQQDLDVSACnFoMV/iA60a+8RfgALRuyBQX4ADQIAEOAA2yExtV6eU4Q+CcvTFt9cNfApyadHUmMfAuYsLZ1je+jjtVRwhw6jM/rg/owCK4N8P5y9eWj3WjH/77JQw5e4+qPUJwhw09uHGTlWUFMVyWmcRGjYYriNCjm3dIG76eEOBUa+QNGqB1mbY3nT/3cF12ApxaPUMQ4tC43AV4qBAX4NRMiEODMpfZ58a/uyfAqZ0QhzblLLTPzK9XBQFOC4YrmAB7BDjN0AoH+EuA0wrpDTAjwAGgQbZSBRiQQ0PaJ8ABBnJ0X3KHhtRPgAMMImJ3tLdDQ74R8OUIcIABnNzadDod8HBL3WqRfExioxVu8+Gki/uSf3vMawOVg13zJCTAaYauOrjk9kNFtL7z0oVOCyQ3nJQxVKV3Zlrg1O4RgtY3XCRcOyTAqZnwBtigC50avRJbeAOsE+BUSXADfKcLHQAaJMABoEECHKBTsyVkxqQ6ZAwcoDN2RRuDAAfoyMVtU2mILnRqo6sPThLeYxHgVMcSMognvMcjwKmJ5IZrhPdABDi1sG0qnOQUsDEJcGogvOE6KT4Ys9ApyZ7nACcJcHJZTWjBDXCOACcHXeQAiRkDJwvhDZBWDwEuGerm8wG4QQ8BbuZlvXSdQz4K2mB6CHDqJLwhE+VsTAKc1B5BeEMpCt1ABDjJ/fvPQ3hDZrMyp/ANwjIygIYc3Db1EcwP6p4AB2jAIri3wlnreyACnOSmikY3OqQRcVSoVvdAjIGT2vPnjxOSIAHnfLNFgHMXIQ4XCW++EeDcSYjDdQoQqwQ4d1P5wAlufNkjwMlCZQSnKDhsEuDkoBICSEyAA0CDBDgANEiAA0CDBDgANEiAA0CDBDjZWEoG0RwowCYBTi7SGyI4DIg9ApystMIhmiRnlQAnJ+kNEWatcCHOBwEOUDEhzhYBDlC5RYgLckIIIfwq/QYA2DeF+M88krUQN0Q1GAEO0JC12ekmh45JFzoANEiAk5OxO4BEBDhZ2ZwCbqNwDcYYOLmoXOAiY93MCXByeISg9Q1nLYJ7K8WnJWZSfhACnLsJb7hgFt57wTx9XYgPQoADXdrrbm7hpjIivOeeQYgP4fH7z9OHzN20wskmors5hFDvdXkyvBmIACeX1Vqy1sqTNp0IvWQ3l6lb/D/Pp35mkwCnpOpbQbTjQov1Uojf0eLX+uYI68Ap6fnzx/IYLrkYeKevwcXrfnuCM9e6QsFXApwaCHFSuHIBRT/2wgQz1zpJCHBqoWLjlJTXzNHnKtXihzkBTk3UaJyV4tqJfY6sLX5YEuBUR8uEmpVo8cMaG7lQm2kTCijuS8CmavF/XOtCnaMEOMDCwaVhzb8mbRPgADMl1mBb980ZxsABPglvqifAgR6kmDcxPUeJIBXeRBPgQNMSb8MrvGmGAKc2ZqAzCtc6lwhwquNgE2IkXHal9U1TzEKnJpKbNxFHdLYWhK51LhPg1CLZucy07+gRnY1ueuIiJwkBTg2ENy8Ry6qmr7twGJIApwrCmxCuHdHZkNbeL5UyiY0qNNoVSkI2NIE4ApwaqLCZuBbgIF3odCdi5jKV0AMD8QQ43YiduSzIqyPFIYIudLqwGD/9FgSvr2v1AS3TAqcqZ7q/L8xcfvz+89QSB5r0+P3nqRlCDeYputn9Pf1jCt0EM5etQa/Az+eoLoIIutCpwfwYxzPd31cqfqEBNEmAU4vojTtSjmEbDwdaI8Ap7RHOtYKfi7+vkN51MI4BEQQ4JZ0N70nS4NUKL84HABEEOCXVVGHX9F4AdglwAGiQdeAws9aNbokZUCMBDn+tdaPbehWokgCH76ZQt2tbAiYKQjp2YoPj7Np20tGDZr58DVgwiQ2OcwjKCZEHzQAHCXCII2QiJNirHtggwOEErfB9whvuJcAhnkA6zu8KbiLAgeT0UMD9BDhwFykONxLgANAgAQ4ADbITG7DpyFi2jW2gDAEO8bpPrIM7p4Uw2yt+ItAhDwEOJ/QcUpHrt5ff8xHowD3shQ5xNpO7h1BPtPnK/BehfoGbaIHDcd8O23hrebYY5gl3TnuGAYYZoDQtcEjvFV6tBLltT6E9lpFBeq9TtxobD27qzcLoBDjcp4kQr/39Aet0ocP9HiHU052+EdjqAWiMSWxwvyomdUWs7QYaoAsdMinZVb2YpCa8oQMCHPIoFppmmEOfBDh0THhDvwQ49E94Q4cEOHTK8jDomwCHvklx6JQAB4AGCXDIo/g6cKAvAhwyqWUnNqAPAhzuJ7mB5GylCpXam0WuRQ9jc5gJ5HH4QJODe5Z/nDn+JfCVceiQFjjkcehAk4id06avPxxSAmMyBg4ZfesWP7nt6XP2t/CGgQhwyGczYC/uWS64YUACHOohiIHDBDgUVmDPctPXoQMCHOqQM8W19KEDAhwKcmIYcJZlZFCApV/AVQIcMrs44xwghKALHXJ7Lv4GOEWAQ37CG7hMgANAgwQ4ADRIgANAgwQ4ADRIgANAgwQ4ADRIgANAgwQ4ADRIgANAgwQ4ADRIgANAgwQ4ADRIgANAgwQ4ADRIgANAgwQ4ADRIgANAgwQ4ADRIgANAgwQ4ADRIgANAg/4PZd+EkvrZ4eMAAAAASUVORK5CYII=')";
        currentLvl = 2;
      }
    } else if (
      keys.f.pressed &&
      mob.position.x - player.position.x < 100 &&
      mob.position.y - player.position.y < 50 &&
      mob.image === norbertImg
    ) {
      document.querySelector(
        "#norbertHealth"
      ).innerHTML = `${amountOfNorbertsHealth} / 500`;
      amountOfNorbertsHealth -= 2;
      if (amountOfNorbertsHealth === 0) {
        mob.visibility = false;
        alert("WYGRALES");
      } else if (amountOfNorbertsHealth < 0) {
        window.location.reload();
      }
    }
    if (
      mob.position.x - player.position.x < 20 &&
      mob.visibility === true &&
      mob.position.y - player.position.y < 50
    ) {
      window.location.reload();
    }
  });

  if (keys.right.pressed && player.position.x < 500) {
    player.velocity.x = 5;
  } else if (keys.left.pressed && player.position.x > 20) {
    player.velocity.x = -5;
  } else {
    player.velocity.x = 0;
    if (keys.right.pressed) {
      platforms.forEach((platform) => {
        platform.position.x -= 5;
      });
    } else if (keys.left.pressed) {
      platforms.forEach((platform) => {
        platform.position.x += 5;
      });
    }
    if (keys.right.pressed) {
      mobs.forEach((mob) => {
        mob.position.x -= 5;
      });
    } else if (keys.left.pressed) {
      mobs.forEach((mob) => {
        mob.position.x += 5;
      });
    }
    if (keys.right.pressed) {
      coins.forEach((coin) => {
        coin.position.x -= 5;
      });
    } else if (keys.left.pressed) {
      coins.forEach((coin) => {
        coin.position.x += 5;
      });
    }
  }

  // detekcja z platformami
  platforms.forEach((platform) => {
    if (
      player.position.y + player.height <= platform.position.y &&
      player.position.y + player.height + player.velocity.y >=
        platform.position.y &&
      player.position.x + player.width >= platform.position.x &&
      player.position.x <= platform.position.x + platform.width
    ) {
      player.velocity.y = 0;
    }
  });
  if (player.position.x <= 30) {
    keys.left.pressed = false;
  } else if (player.position.x >= 2000) {
    keys.right.pressed = false;
    player.velocity.x = 0;
  }
}
// wywolanie funkcji animate
animate();

addEventListener("keyup", ({ keyCode }) => {
  switch (keyCode) {
    case 70:
      // wcisniety przycisk uderzenia
      keys.f.pressed = false;
      break;
    case 37:
      // wcisnieta strzalka w lewo
      keys.left.pressed = false;
      break;
    case 40:
      // wcisnieta strzalka w dół
      break;
    case 39:
      // wcisnieta strzalka w prawo
      keys.right.pressed = false;
      break;
    case 38:
      // wcisnieta strzalka w górę
      keys.up.pressed = true;
      setTimeout(() => {
        keys.up.pressed = false;
      }, 1000);
      break;
  }
});
addEventListener("keydown", ({ keyCode }) => {
  switch (keyCode) {
    case 70:
      // wcisniety przycisk uderzenia
      keys.f.pressed = true;
      player.velocity.y = 0;
      break;
    case 37:
      // wcisnieta strzalka w lewo
      if (player.position.x > 20) {
        keys.left.pressed = true;
      }
      break;
    case 40:
      // wcisnieta strzalka w dół
      break;
    case 39:
      // wcisnieta strzalka w prawo
      keys.right.pressed = true;
      keys.f.pressed = false;
      break;
    case 38:
      // wcisnieta strzalka w górę
      player.velocity.y -= 10;
      keys.up.pressed = true;
      setTimeout(() => {
        keys.up.pressed = false;
      }, 1000);
      break;
  }
});
